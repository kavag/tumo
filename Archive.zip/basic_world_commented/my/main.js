let user = "user";
start();

function start() {
    var coms = ["ver", "alert", "doc"];
    var consola = prompt("root" + "@" + user);
    if(consola == coms[0]) {
        alert("Consola by NT3. Ver. v1.0.0.");
    }
    else if(consola == coms[1]) {
        var alertTxt = prompt("Enter your text for alert.");
        alert(alertTxt);
    }
    else if(consola == coms[2]) {
        var docTxt = prompt("root" + "@" + user + ":" + coms[2]);
        var docRes = docTxt;
        document.getElementById("doc").innerHTML = docRes;
    }

    // Start/Stop Commands

    var comControls = ["stop", "restart", "exit"];
    if(consola == comControls[0]) {
        alert("Project was stopped.");
    }
    else if(consola == comControls[1]) {
        alert("Project was restarting.");
        setTimeout(2000, start());
    }
    else if(consola == comControls[2]) {
        alert("You was exited.");
    }

    // Tips and Advices

    if(consola == "tip") {
        var tips = ["Click cancel for preferences.", 
        "If you want to check console settings, click Cancel.", 
        "Love programs by NT3"];
        var randomTip = tips[Math.floor(Math.random(tips) * 4)];
        alert(randomTip);
    }
    else if(consola == "contact") {
        alert("Contact: ashot.m2.y@tumo.org");
    }

    // If nothing haves in console.
    else if(consola != coms.length) {
        alert("Command is not real or written incorrect.");
    }
}