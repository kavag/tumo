let arrays = require('./modules/arrays');
let Grass = require('./modules/grass');
let Grasseater = require('./modules/grasseater');

var LiveForm = require('./modules/LiveForm');
var matrix = require('./modules/matrix');

var express = require('express');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);

app.use(express.static("."));
app.get('/', function (req, res) {
   res.redirect('index.html');
});

io.sockets.on("draw", creator);

function creator() {
    for(var y = 0; y < matrix.length; y++) {
        for(var X = 0; x < matrix[i].length; x++) {
            if(matrix[y][x] == 2) {
                var eatgrass = new Grasseater(x,y, 1);
                arrays.eatArr.push(eatgrass);
            }
            else if(matrix[y][x] == 1) {
                var grass = new Grass(x,y, 1);
                arrays.xotArr.push(grass);
            }
        }
    }
}

// Server log
console.log("Connection was established.");

server.listen(3000);