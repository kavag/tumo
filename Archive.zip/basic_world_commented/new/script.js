var side = 25;

var grassArr = [];
var eaterArr = [];
var predArr = [];

var oneArr = [];
var secArr = [];

var matrix = [
    [0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1],
    [0, 1, 1, 0, 0, 2, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1],
    [0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1],
    [0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1],
    [0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1],
    [0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1],
    [2, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [2, 0, 0, 0, 0, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 1, 0, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1],
]

function setup() {
    frameRate(10);
    createCanvas(matrix[0].length * side, matrix.length * side);
    background('#acacac');

    for(var y = 0; y < matrix.length; y++) {
        for(var x = 0; x < matrix.length; x++) {
            if(matrix[y][x] == 1) {
                var grass = new Grass(x,y);
                grassArr.push(grass);
            }
            else if(matrix[y][x] == 2) {
                var eater = new Grasseater(x,y);
                eaterArr.push(eater);
            }
            // else if(matrix[y][x] == 3) {
            //     var predator = new Predator(x,y);
            //     predArr.push(predator);
            // }
            // else if(matrix[y][x] == 4) {
            //     var person1 = new Person1(x,y);
            //     oneArr.push(person1);
            // }
            // else if(matrix[y][x] == 5) {
            //     var person2 = new Person2(x,y);
            //     secArr.push(person2);
            // }
        }
    }
}

function draw() {
    background('#acacac');
    for(var i = 0; i < matrix.length; i++) {
        for(var j = 0; j < matrix[i].length; j++) {
            if(matrix[i][j] == 0) {
                fill('#acacac');
                rect(j*side, i*side, side, side);
            }
            else if(matrix[i][j] == 1) {
                fill("green");
                rect(j*side, i*side, side, side);
            }
            else if(matrix[i][j] == 2) {
                fill("orange");
                rect(j*side, i*side, side, side);
            }
        }
    }
}