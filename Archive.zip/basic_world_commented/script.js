var side = 25;
var sockets = io();

let arrays = require('./modules/arrays');
let LiveForm = require('./modules/LiveForm');
let Grass = require('./modules/grass');
let Eatgrass = require('./modules/grasseater');
let matrix = require('./modules/matrix');

let matrix = [];

io.sockets.emit("draw", creator);

// function creator() {
//     background('#acacac');
//     for (var i = 0; i < matrix.length; i++) {
//         for (var j = 0; j < matrix[i].length; j++) {
//             if (matrix[i][j] == 1) {
//                 fill("green");
//                 rect(j * side, i * side, side, side);
//             } else if (matrix[i][j] == 2) {
//                 fill("yellow");
//                 rect(j * side, i * side, side, side);
//             } else if (matrix[i][j] == 0) {
//                 fill('gray');
//                 rect(j * side, i * side, side, side);
//             }
//             else if (matrix[i][j] == 3) {
//                 fill('orange');
//                 rect(j * side, i * side, side, side);
//             }
//             else if(matrix [i][j] == 4){
//                 fill("red");
//                 rect(j * side,i * side, side, side);
//             }
//             else if(matrix [i][j] == 5){
//                 fill("blue");
//                 rect(j * side,i * side, side, side);
//             }
//         }
//     }
// }

creator();