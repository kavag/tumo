class LiveForm {
    constructor(x,y) {
        this.x = x;
        this.y = y;
        this.multiply = 0;
        this.directions = [];
    }
}