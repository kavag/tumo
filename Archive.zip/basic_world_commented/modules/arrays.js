module.exports = {
    eatArr: [],
    xotArr: [],
    gishatichArr: [],
    krakArr: [],
    jurArr: [],
}